-- Update the profile to link to the auth user properly if needed
UPDATE public.profiles 
SET id = 'd060b78e-0924-4dc6-9715-c2a47a6a2834'
WHERE full_name = 'Lynn Eckeberger' AND role = 'admin';