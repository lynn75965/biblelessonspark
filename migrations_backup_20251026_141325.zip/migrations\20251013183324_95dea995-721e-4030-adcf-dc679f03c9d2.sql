DO \$\$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema='public' AND table_name='events')
  THEN
-- Phase 0: Baseline Architecture for LessonSparkUSA Subscriptions & Credits
-- Store money in integer cents, use NULL for unlimited, enforce single owner

-- 1) subscription_plans table
CREATE TABLE public.subscription_plans (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  price_monthly_cents int NOT NULL,
  price_yearly_cents int NOT NULL,
  currency text NOT NULL DEFAULT 'usd',
  credits_monthly int NULL, -- NULL = unlimited
  lookup_key text UNIQUE NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.subscription_plans ENABLE ROW LEVEL SECURITY;

-- RLS: Public can SELECT subscription plans (for pricing page)
CREATE POLICY "Public can view subscription plans"
ON public.subscription_plans
FOR SELECT
USING (true);

-- 2) user_subscriptions table
CREATE TABLE public.user_subscriptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  plan_id uuid REFERENCES public.subscription_plans(id),
  current_period_start timestamptz NOT NULL,
  current_period_end timestamptz NOT NULL,
  status text NOT NULL DEFAULT 'trialing' CHECK (status IN ('trialing', 'active', 'past_due', 'canceled')),
  cancel_at_period_end boolean NOT NULL DEFAULT false,
  stripe_customer_id text,
  stripe_subscription_id text,
  stripe_product_id text,
  stripe_price_id text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- Partial unique index: only one active/trialing/past_due subscription per user
CREATE UNIQUE INDEX user_subscriptions_active_unique 
ON public.user_subscriptions(user_id) 
WHERE status IN ('trialing', 'active', 'past_due');

ALTER TABLE public.user_subscriptions ENABLE ROW LEVEL SECURITY;

-- RLS: Users can view their own subscriptions
CREATE POLICY "Users can view own subscriptions"
ON public.user_subscriptions
FOR SELECT
USING (user_id = auth.uid());

-- Service role can insert/update (via webhooks)
CREATE POLICY "Service role can manage subscriptions"
ON public.user_subscriptions
FOR ALL
USING (auth.jwt()->>'role' = 'service_role')
WITH CHECK (auth.jwt()->>'role' = 'service_role');

-- 3) credits_ledger table
CREATE TABLE public.credits_ledger (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  amount int NOT NULL, -- positive = add, negative = deduct
  reference_type text NOT NULL CHECK (reference_type IN ('system_allocation', 'generation', 'refund', 'webhook', 'manual')),
  reference_id uuid NULL,
  idempotency_key text UNIQUE NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.credits_ledger ENABLE ROW LEVEL SECURITY;

-- RLS: Users can view their own ledger
CREATE POLICY "Users can view own credits ledger"
ON public.credits_ledger
FOR SELECT
USING (user_id = auth.uid());

-- Service role can insert/update/delete
CREATE POLICY "Service role can manage credits ledger"
ON public.credits_ledger
FOR ALL
USING (auth.jwt()->>'role' = 'service_role')
WITH CHECK (auth.jwt()->>'role' = 'service_role');

-- 4) credits_balance VIEW
CREATE OR REPLACE VIEW public.credits_balance AS
SELECT 
  user_id,
  COALESCE(SUM(amount), 0) as balance
FROM public.credits_ledger
GROUP BY user_id;

-- 5) stripe_events table (for webhook idempotency)
CREATE TABLE public.stripe_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  event_id text UNIQUE NOT NULL,
  event_type text NOT NULL,
  processed_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.stripe_events ENABLE ROW LEVEL SECURITY;

-- Only service role can manage stripe events
CREATE POLICY "Service role can manage stripe events"
ON public.stripe_events
FOR ALL
USING (auth.jwt()->>'role' = 'service_role')
WITH CHECK (auth.jwt()->>'role' = 'service_role');

-- 6) admin_audit table
CREATE TABLE public.admin_audit (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  actor_user_id uuid NOT NULL,
  action text NOT NULL,
  target_user_id uuid,
  target_org_id uuid,
  payload jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.admin_audit ENABLE ROW LEVEL SECURITY;

-- Admins can view audit logs
CREATE POLICY "Admins can view audit logs"
ON public.admin_audit
FOR SELECT
USING (has_role(auth.uid(), 'admin'));

-- Service role can insert audit logs
CREATE POLICY "Service role can insert audit logs"
ON public.admin_audit
FOR INSERT
WITH CHECK (auth.jwt()->>'role' = 'service_role');

-- 7) Update profiles table
ALTER TABLE public.profiles 
  ADD COLUMN IF NOT EXISTS subscription_tier text,
  ADD COLUMN IF NOT EXISTS subscription_status text;

-- 8) SQL Functions

-- get_credits_balance function
CREATE OR REPLACE FUNCTION public.get_credits_balance(p_user_id uuid)
RETURNS integer
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $fn$
  SELECT COALESCE(SUM(amount), 0)::integer
  FROM public.credits_ledger
  WHERE user_id = p_user_id;
$fn$;

-- deduct_credits function with advisory lock and exception handling
CREATE OR REPLACE FUNCTION public.deduct_credits(
  p_user_id uuid,
  p_amount integer,
  p_reference_id uuid,
  p_reference_type text,
  p_idempotency_key text
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $fn$
DECLARE
  v_current_balance integer;
  v_new_balance integer;
BEGIN
  -- Acquire advisory lock for this user (prevents concurrent credit deductions)
  PERFORM pg_advisory_xact_lock(hashtext(p_user_id::text));
  
  -- Check if this idempotency key was already processed
  IF EXISTS (SELECT 1 FROM public.credits_ledger WHERE idempotency_key = p_idempotency_key) THEN
    RETURN jsonb_build_object('success', true, 'message', 'already_processed');
  END IF;
  
  -- Get current balance
  v_current_balance := public.get_credits_balance(p_user_id);
  v_new_balance := v_current_balance - p_amount;
  
  -- Check if sufficient credits
  IF v_new_balance < 0 THEN
    RAISE EXCEPTION 'insufficient_credits' USING HINT = 'User does not have enough credits';
  END IF;
  
  -- Deduct credits
  INSERT INTO public.credits_ledger (
    user_id,
    amount,
    reference_type,
    reference_id,
    idempotency_key
  ) VALUES (
    p_user_id,
    -p_amount,
    p_reference_type,
    p_reference_id,
    p_idempotency_key
  );
  
  RETURN jsonb_build_object(
    'success', true,
    'previous_balance', v_current_balance,
    'new_balance', v_new_balance,
    'amount_deducted', p_amount
  );
END;
$fn$;

-- allocate_monthly_credits function (idempotent)
CREATE OR REPLACE FUNCTION public.allocate_monthly_credits(
  p_subscription_id uuid
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $fn$
DECLARE
  v_user_id uuid;
  v_credits_amount integer;
  v_period_start timestamptz;
  v_idempotency_key text;
BEGIN
  -- Get subscription details
  SELECT 
    us.user_id,
    sp.credits_monthly,
    us.current_period_start
  INTO v_user_id, v_credits_amount, v_period_start
  FROM public.user_subscriptions us
  JOIN public.subscription_plans sp ON us.plan_id = sp.id
  WHERE us.id = p_subscription_id;
  
  IF v_user_id IS NULL THEN
    RAISE EXCEPTION 'subscription_not_found';
  END IF;
  
  -- NULL credits_monthly means unlimited, so no allocation needed
  IF v_credits_amount IS NULL THEN
    RETURN jsonb_build_object('success', true, 'message', 'unlimited_plan');
  END IF;
  
  -- Create idempotency key: alloc-<subscription_id>-<period_start>
  v_idempotency_key := 'alloc-' || p_subscription_id::text || '-' || extract(epoch from v_period_start)::text;
  
  -- Check if already allocated
  IF EXISTS (SELECT 1 FROM public.credits_ledger WHERE idempotency_key = v_idempotency_key) THEN
    RETURN jsonb_build_object('success', true, 'message', 'already_allocated');
  END IF;
  
  -- Allocate credits
  INSERT INTO public.credits_ledger (
    user_id,
    amount,
    reference_type,
    reference_id,
    idempotency_key
  ) VALUES (
    v_user_id,
    v_credits_amount,
    'system_allocation',
    p_subscription_id,
    v_idempotency_key
  );
  
  RETURN jsonb_build_object(
    'success', true,
    'credits_allocated', v_credits_amount,
    'user_id', v_user_id
  );
END;
$fn$;

-- Update timestamp trigger
CREATE TRIGGER update_subscription_plans_updated_at
BEFORE UPDATE ON public.subscription_plans
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_user_subscriptions_updated_at
BEFORE UPDATE ON public.user_subscriptions
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Seed subscription plans
INSERT INTO public.subscription_plans (name, price_monthly_cents, price_yearly_cents, currency, credits_monthly, lookup_key)
VALUES
  ('Essentials', 1900, 18200, 'usd', 50, 'essentials_monthly'),
  ('Pro', 4900, 47000, 'usd', 200, 'pro_monthly'),
  ('Premium', 9900, 95000, 'usd', NULL, 'premium_monthly')
ON CONFLICT (lookup_key) DO NOTHING;
  END IF;
END \$\$;