-- Strengthen RLS policies to prevent self-role modification and add audit logging

-- First, drop existing policies to replace them with secure ones
DROP POLICY IF EXISTS "profiles_secure_self_update" ON public.profiles;
DROP POLICY IF EXISTS "profiles_admin_manage_all" ON public.profiles;

-- Create a security definer function to check admin status
CREATE OR REPLACE FUNCTION public.is_admin(user_id uuid DEFAULT auth.uid())
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $fn$
  SELECT EXISTS (
    SELECT 1 FROM public.profiles 
    WHERE id = user_id AND role = 'admin'
  );
$fn$;

-- Create secure policy for self-profile updates (prevents role changes)
CREATE POLICY "profiles_secure_self_update" 
ON public.profiles 
FOR UPDATE 
USING (id = auth.uid())
WITH CHECK (
  id = auth.uid() 
  AND role = (SELECT role FROM public.profiles WHERE id = auth.uid())
  AND founder_status = (SELECT founder_status FROM public.profiles WHERE id = auth.uid())
);

-- Create admin-only policy for role management
CREATE POLICY "profiles_admin_manage_roles" 
ON public.profiles 
FOR UPDATE 
USING (public.is_admin())
WITH CHECK (public.is_admin());

-- Add admin visibility policy for all profiles
CREATE POLICY "profiles_admin_view_all" 
ON public.profiles 
FOR SELECT 
USING (public.is_admin() OR id = auth.uid());

-- Create trigger to log role changes
CREATE OR REPLACE FUNCTION public.log_profile_role_changes()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $fn$
BEGIN
  -- Log when roles are changed
  IF OLD.role IS DISTINCT FROM NEW.role THEN
    PERFORM public.log_security_event(
      'role_changed',
      NEW.id,
      jsonb_build_object(
        'old_role', OLD.role,
        'new_role', NEW.role,
        'changed_by', auth.uid(),
        'target_user', NEW.full_name
      )
    );
  END IF;
  
  -- Log when founder status changes
  IF OLD.founder_status IS DISTINCT FROM NEW.founder_status THEN
    PERFORM public.log_security_event(
      'founder_status_changed',
      NEW.id,
      jsonb_build_object(
        'old_status', OLD.founder_status,
        'new_status', NEW.founder_status,
        'changed_by', auth.uid(),
        'target_user', NEW.full_name
      )
    );
  END IF;
  
  RETURN NEW;
END;
$fn$;

-- Create trigger for role change logging
DROP TRIGGER IF EXISTS profile_role_changes_trigger ON public.profiles;
CREATE TRIGGER profile_role_changes_trigger
  AFTER UPDATE ON public.profiles
  FOR EACH ROW
  EXECUTE FUNCTION public.log_profile_role_changes();