-- ============================================
-- CRITICAL SECURITY FIX: Separate Roles Architecture
-- ============================================

-- 1. Create app_role enum
CREATE TYPE public.app_role AS ENUM ('admin', 'teacher', 'moderator');

-- 2. Create user_roles table
CREATE TABLE public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role public.app_role NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  created_by UUID REFERENCES auth.users(id),
  UNIQUE (user_id, role)
);

-- Enable RLS on user_roles
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

-- Create index for performance
CREATE INDEX idx_user_roles_user_id ON public.user_roles(user_id);
CREATE INDEX idx_user_roles_role ON public.user_roles(role);

-- 3. Create security definer function to check roles (breaks RLS recursion)
CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role public.app_role)
RETURNS BOOLEAN
LANGUAGE SQL
STABLE
SECURITY DEFINER
SET search_path = public
AS $fn$
  SELECT EXISTS (
    SELECT 1
    FROM public.user_roles
    WHERE user_id = _user_id
      AND role = _role
  );
$fn$;

-- 4. Migrate existing roles from profiles to user_roles
INSERT INTO public.user_roles (user_id, role, created_at)
SELECT id, role::public.app_role, created_at
FROM public.profiles
WHERE role IN ('admin', 'teacher')
ON CONFLICT (user_id, role) DO NOTHING;

-- 5. Update is_admin() function to use user_roles table
CREATE OR REPLACE FUNCTION public.is_admin(user_id UUID DEFAULT auth.uid())
RETURNS BOOLEAN
LANGUAGE SQL
STABLE
SECURITY DEFINER
SET search_path = public
AS $fn$
  SELECT EXISTS (
    SELECT 1 FROM public.user_roles 
    WHERE user_roles.user_id = is_admin.user_id AND role = 'admin'
  );
$fn$;

-- 6. Update verify_admin_access function
CREATE OR REPLACE FUNCTION public.verify_admin_access(user_id UUID DEFAULT auth.uid())
RETURNS BOOLEAN
LANGUAGE SQL
STABLE
SECURITY DEFINER
SET search_path = public
AS $fn$
  SELECT public.has_role(user_id, 'admin');
$fn$;

-- ============================================
-- RLS POLICIES FOR user_roles TABLE
-- ============================================

-- Admins can view all user roles
CREATE POLICY "Admins can view all user roles"
ON public.user_roles
FOR SELECT
USING (public.has_role(auth.uid(), 'admin'));

-- Users can view their own roles
CREATE POLICY "Users can view own roles"
ON public.user_roles
FOR SELECT
USING (user_id = auth.uid());

-- Only admins can insert/update/delete roles
CREATE POLICY "Admins can manage user roles"
ON public.user_roles
FOR ALL
USING (public.has_role(auth.uid(), 'admin'));

-- ============================================
-- UPDATE PROFILES TABLE POLICIES
-- ============================================

-- Drop old admin policy that checked profiles.role
DROP POLICY IF EXISTS "profiles_admin_manage_roles" ON public.profiles;
DROP POLICY IF EXISTS "profiles_admin_manage_all" ON public.profiles;
DROP POLICY IF EXISTS "Admins can manage all profiles" ON public.profiles;

-- Create new admin policy using has_role
CREATE POLICY "profiles_admin_manage_roles"
ON public.profiles
FOR UPDATE
USING (public.has_role(auth.uid(), 'admin'))
WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- Update profiles_org_admin_view_all to use has_role
DROP POLICY IF EXISTS "profiles_org_admin_view_all" ON public.profiles;
CREATE POLICY "profiles_org_admin_view_all"
ON public.profiles
FOR SELECT
USING (
  public.has_role(auth.uid(), 'admin') 
  OR id = auth.uid() 
  OR organization_id IN (
    SELECT organization_id 
    FROM organization_members 
    WHERE user_id = auth.uid() AND role IN ('admin', 'owner')
  )
);

-- Add INSERT policy for profiles (defense-in-depth)
CREATE POLICY "Users can insert own profile"
ON public.profiles
FOR INSERT
WITH CHECK (
  id = auth.uid() 
);

-- Admins can create profiles for others
CREATE POLICY "Admins can create profiles"
ON public.profiles
FOR INSERT
WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- ============================================
-- STORAGE POLICIES FOR lesson-uploads BUCKET
-- ============================================

-- Users can view their own lesson uploads
CREATE POLICY "Users can view own lesson uploads"
ON storage.objects
FOR SELECT
USING (
  bucket_id = 'lesson-uploads' 
  AND auth.uid()::text = (storage.foldername(name))[1]
);

-- Users can upload to their own folder
CREATE POLICY "Users can upload to own folder"
ON storage.objects
FOR INSERT
WITH CHECK (
  bucket_id = 'lesson-uploads' 
  AND auth.uid()::text = (storage.foldername(name))[1]
);

-- Users can update their own uploads
CREATE POLICY "Users can update own uploads"
ON storage.objects
FOR UPDATE
USING (
  bucket_id = 'lesson-uploads' 
  AND auth.uid()::text = (storage.foldername(name))[1]
);

-- Users can delete their own uploads
CREATE POLICY "Users can delete own uploads"
ON storage.objects
FOR DELETE
USING (
  bucket_id = 'lesson-uploads' 
  AND auth.uid()::text = (storage.foldername(name))[1]
);

-- ============================================
-- ORGANIZATION CONTACT INFO RESTRICTION
-- ============================================

-- Drop existing broad member policy
DROP POLICY IF EXISTS "Members can view basic organization info" ON public.organizations;

-- Create separate policies for different access levels

-- All members can view basic org info (name, type, description, website)
CREATE POLICY "Members can view basic organization info"
ON public.organizations
FOR SELECT
USING (
  id IN (
    SELECT organization_id 
    FROM organization_members 
    WHERE user_id = auth.uid()
  )
);

-- Note: Contact info (email, phone, address) restriction is enforced at application level
-- for compatibility. For stricter security, create a separate organization_contacts table.

-- Only admins/owners can view full organization details including contact info
-- This is implemented via application-level filtering in the useOrganization hook

-- ============================================
-- SECURITY AUDIT LOGGING ENHANCEMENTS
-- ============================================

-- Update log_profile_role_changes to work with new system
CREATE OR REPLACE FUNCTION public.log_role_changes()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $fn$
BEGIN
  -- Log role additions
  IF TG_OP = 'INSERT' THEN
    PERFORM public.log_security_event(
      'role_assigned',
      NEW.user_id,
      jsonb_build_object(
        'role', NEW.role,
        'assigned_by', NEW.created_by,
        'timestamp', NEW.created_at
      )
    );
  END IF;
  
  -- Log role removals
  IF TG_OP = 'DELETE' THEN
    PERFORM public.log_security_event(
      'role_removed',
      OLD.user_id,
      jsonb_build_object(
        'role', OLD.role,
        'removed_by', auth.uid(),
        'timestamp', now()
      )
    );
  END IF;
  
  RETURN COALESCE(NEW, OLD);
END;
$fn$;

-- Create trigger for role change logging
DROP TRIGGER IF EXISTS user_role_changes_trigger ON public.user_roles;
CREATE TRIGGER user_role_changes_trigger
  AFTER INSERT OR DELETE ON public.user_roles
  FOR EACH ROW
  EXECUTE FUNCTION public.log_role_changes();

-- ============================================
-- DEPRECATION NOTICE FOR profiles.role
-- ============================================

-- Add comment to profiles.role column indicating it's deprecated
COMMENT ON COLUMN public.profiles.role IS 'DEPRECATED: Use user_roles table instead. This column is kept for backward compatibility only and should not be used for authorization checks.';

-- Note: We keep the profiles.role column for now to avoid breaking existing queries,
-- but all authorization checks should use the has_role() function and user_roles table.