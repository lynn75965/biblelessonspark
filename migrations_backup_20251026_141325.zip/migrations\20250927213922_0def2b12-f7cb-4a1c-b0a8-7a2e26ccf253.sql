DO \$\$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema='public' AND table_name='invites')
  THEN
-- Strengthen invite email protection - tighten RLS policies
DROP POLICY IF EXISTS "User can read their own email invites" ON public.invites;
DROP POLICY IF EXISTS "Users can only read invites for their verified email" ON public.invites;

-- More restrictive policy that prevents email enumeration
CREATE POLICY "Users can only read invites for their verified email"
ON public.invites
FOR SELECT
TO authenticated
USING (
  (auth.uid() IS NOT NULL) 
  AND (
    (created_by = auth.uid()) -- Creator can see their invites
    OR (
      email = (SELECT auth.email()) -- Only if email exactly matches authenticated user's email
      AND (claimed_by IS NULL OR claimed_by = auth.uid()) -- And not claimed by someone else
    )
  )
);

-- Add constraint to prevent email enumeration through timing attacks
CREATE OR REPLACE FUNCTION public.validate_invite_email()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $fn$
BEGIN
  -- Ensure email is properly formatted
  IF NEW.email !~ '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$' THEN
    RAISE EXCEPTION 'Invalid email format';
  END IF;
  
  -- Limit invite creation rate per user
  IF (
    SELECT COUNT(*) 
    FROM public.invites 
    WHERE created_by = auth.uid() 
    AND created_at > now() - interval '1 hour'
  ) > 10 THEN
    RAISE EXCEPTION 'Too many invites created in the last hour';
  END IF;
  
  RETURN NEW;
END;
$fn$;

-- Add trigger for invite validation
DROP TRIGGER IF EXISTS validate_invite_email_trigger ON public.invites;
CREATE TRIGGER validate_invite_email_trigger
  BEFORE INSERT ON public.invites
  FOR EACH ROW
  EXECUTE FUNCTION public.validate_invite_email();

-- Enhanced admin role validation - create centralized admin check function
CREATE OR REPLACE FUNCTION public.verify_admin_access(user_id uuid DEFAULT auth.uid())
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $fn$
  SELECT EXISTS (
    SELECT 1 FROM public.profiles 
    WHERE id = user_id AND role = 'admin'
  );
$fn$;
  END IF;
END \$\$;